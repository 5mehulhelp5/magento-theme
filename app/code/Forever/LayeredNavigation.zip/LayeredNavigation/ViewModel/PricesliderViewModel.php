<?php

namespace Forever\LayeredNavigation\ViewModel;

class PricesliderViewModel implements \Magento\Framework\View\Element\Block\ArgumentInterface
{

    /**
     * @var array
     */
    protected $configModule;

    /**
     * @var \Forever\LayeredNavigation\Helper\Configdata
     * */
    protected $_moduleHelper;

    /**
     * @var \Magento\Catalog\Helper\Data
     */
    protected $_data;

    /**
     * @var \Magento\Tax\Helper\Data
     */
    protected $texdata;

    /**
     * @var \Magento\Framework\Json\Helper\Data
     */
    protected $jsondata;

    /**
     * @var \Laminas\Uri\Uri
     */
    protected $laminasUri;

    /**
     * @param \Magento\Catalog\Helper\Data $data
     * @param \Magento\Tax\Helper\Data $texdata
     * @param \Magento\Framework\Json\Helper\Data $jsondata
     * @param \Forever\LayeredNavigation\Helper\Configdata $moduleHelper
     * @param \Laminas\Uri\Uri $laminasUri
     */
    public function __construct(
        \Magento\Catalog\Helper\Data $data,
        \Magento\Tax\Helper\Data $texdata,
        \Magento\Framework\Json\Helper\Data $jsondata,
        \Forever\LayeredNavigation\Helper\Configdata $moduleHelper,
        \Laminas\Uri\Uri $laminasUri
    ) {
        $this->_data = $data;
        $this->texdata = $texdata;
        $this->jsondata = $jsondata;
        $this->_moduleHelper = $moduleHelper;
        $this->laminasUri = $laminasUri;
    }

    /**
     * this function returns count
     * @return int
     * */
    public function shouldDisplayProductCountOnLayer()
    {
        return $this->_data->shouldDisplayProductCountOnLayer();
    }

    /**
     * @param $value
     *
     * @return Priceformat
     * */
    public function getPriceFormat($value)
    {
        return $this->texdata->getPriceFormat($value);
    }

    /**
     * @return \Magento\Framework\Json\Helper\Data
     * */
    public function getjsondata()
    {
        return $this->jsondata;
    }

    /**
     * Check Configuration value
     *
     * @return bool
     * */
    public function getSlider()
    {
        return $this->_moduleHelper->isEnabled();
    }

    /**
     * Parse URL using Laminas Uri
     *
     * @param string $parseUrl
     * @return \Laminas\Uri\Uri
     */
    public function getParseurl($parseUrl)
    {
        return $this->laminasUri->parse($parseUrl);
    }
}
