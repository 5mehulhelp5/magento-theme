<?php

namespace Forever\LayeredNavigation\Block;

use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Magento\Framework\Registry;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Magento\Catalog\Model\Product\Visibility;
use Magento\Catalog\Model\ResourceModel\Product\Collection;
use Magento\Catalog\Model\ProductFactory;

class Layerednav extends Template
{
    /**
     * @var Registry
     */
    protected $_registry;

    /**
     * @var CollectionFactory
     */
    protected $_productCollectionFactory;

    /**
     * @var Visibility
     */
    protected $_catalogProductVisibility;

    /**
     * @var Collection
     */
    protected $_ProductCollection;

    /**
     * @var ProductFactory
     */
    protected $_productFactory;

    /**
     * @param Context $context
     * @param Registry $registry
     * @param CollectionFactory $productCollectionFactory
     * @param Visibility $catalogProductVisibility
     * @param Collection $ProductCollection
     * @param ProductFactory $productFactory
     * @param array $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        CollectionFactory $productCollectionFactory,
        Visibility $catalogProductVisibility,
        Collection $ProductCollection,
        ProductFactory $productFactory,
        array $data = []
    ) {
        $this->_registry = $registry;
        $this->_productCollectionFactory = $productCollectionFactory;
        $this->_catalogProductVisibility = $catalogProductVisibility;
        $this->_ProductCollection = $ProductCollection;
        $this->_productFactory = $productFactory;
        parent::__construct($context, $data);
    }

    /**
     * @return \Magento\Catalog\Model\Category|null
     */
    public function getCurrentCategory()
    {
        return $this->_registry->registry('current_category');
    }

    /**
     * @return string
     */
    public function getCurrencySymbol()
    {
        return $this->_currency->getCurrencySymbol();
    }

    /**
     * Return min and max price for the current category
     *
     * @return array|false
     */
    public function getCurrentCategoryMaxPrice()
    {
        $current_category = $this->getCurrentCategory();
        $currencyRate     = $this->getCurrencyRate();
        if ($current_category) {
            $productModel = $this->_productFactory->create();
            $collection = $productModel->getResourceCollection()
                ->addAttributeToSelect('*')
                ->addCategoryFilter($current_category)
                ->addAttributeToSort('price', 'desc');
            $RangePrice = [];

            $product = $collection->getFirstItem();
            $max_price = $product->getFinalPrice();
            if ($product->getTypeId() == 'bundle' || $product->getTypeId() == 'grouped') {
                $max_price = $product->getMinPrice();
            }
            $max_price = $currencyRate * $max_price;
            $RangePrice['max'] = ceil($max_price);

            $product = $collection->getLastItem();
            $min_price = $product->getFinalPrice();
            if ($product->getTypeId() == 'bundle' || $product->getTypeId() == 'grouped') {
                $min_price = $product->getMinPrice();
            }
            $min_price = $currencyRate * $min_price;
            $RangePrice['min'] = floor($min_price);
            return $RangePrice;
        } else {
            return false;
        }
    }

    /**
     * Retrieve active currency rate for filter
     *
     * @return float
     */
    public function getCurrencyRate()
    {
        $rate = $this->_getData('currency_rate');
        if ($rate === null) {
            $rate = $this->_storeManager->getStore()
                ->getCurrentCurrencyRate();
        }
        if (!$rate) {
            $rate = 1;
        }

        return $rate;
    }
}
