<?php

namespace Forever\Blog\Controller\Index;

use Magento\Framework\App\Action\HttpGetActionInterface;

class View extends \Magento\Framework\App\Action\Action implements HttpGetActionInterface
{
    protected $resultPageFactory;

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory
    ) {
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        return $this->resultPageFactory->create();
    }
}
