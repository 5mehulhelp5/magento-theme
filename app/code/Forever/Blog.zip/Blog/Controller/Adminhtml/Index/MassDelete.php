<?php

/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Forever\Blog\Controller\Adminhtml\Index;

use Magento\Framework\Controller\ResultFactory;

/**
 * @Class MassDelete
 * package Forever\CustomerReview\Controller\Adminhtml\Index
 */
class MassDelete extends \Magento\Backend\App\Action
{
    protected $blogFactory;
    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Forever\Blog\Model\BlogFactory     $blogFactory
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Forever\Blog\Model\ResourceModel\Blog\CollectionFactory $blogFactory,
        \Magento\Ui\Component\MassAction\Filter $filter
    ) {
        $this->blogFactory = $blogFactory;
        $this->filter = $filter;
        parent::__construct($context);
    }

    /**
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     */
    public function execute()
    {
        $collection = $this->filter->getCollection($this->blogFactory->create());
        $recordDeleted = 0;
         
        foreach ($collection->getItems() as $record) {
            $record->setId($record->getBlogId());
            $record->delete();
            $recordDeleted++;
        }
        $this->messageManager->addSuccessMessage(__('A total of %1 record(s) have been deleted.', $recordDeleted));

        return $this->resultFactory->create(ResultFactory::TYPE_REDIRECT)->setPath('blog/index/index');
    }

    /**
     * @return bool
     */
    protected function isAllowed()
    {
        return $this->_authorization->isAllowed('Forever_Blog::home');
    }
}
