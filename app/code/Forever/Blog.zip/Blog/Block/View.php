<?php

/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Forever\Blog\Block;

use Magento\Framework\View\Element\Template;

class View extends Template
{
    /**
     * @var $blogFactory
     */
    protected $blogFactory;

    /**
     * @return helperImageFactory
     */
    protected $helperImageFactory;

    /**
     * @return assetRepos
     */
    protected $assetRepos;
    
    /**
     * @param Template\Context                $context
     * @param \Forever\Blog\Model\BlogFactory $blogFactory
     * @param \Magento\Framework\View\Asset\Repository $assetRepos
     * @param \Magento\Catalog\Helper\ImageFactory $helperImageFactory
     * @param array                           $data
     */
    public function __construct(
        Template\Context $context,
        \Forever\Blog\Model\BlogFactory $blogFactory,
        \Magento\Framework\View\Asset\Repository $assetRepos,
        \Magento\Catalog\Helper\ImageFactory $helperImageFactory,
        array $data = []
    ) {

        parent::__construct($context, $data);
        $this->blogFactory = $blogFactory;
        $this->assetRepos = $assetRepos;
        $this->helperImageFactory = $helperImageFactory;
    }
    /**
     * @param  $urlKey
     * @return $getPost
     */
    public function getPost($urlKey)
    {
        $collection = $this->blogFactory->create()->load($urlKey, 'url_key');
        return $collection;
    }

    /**
     * @return Place Holder Image
     */
    public function getPlaceHolderImage()
    {
        $imagePlaceholder = $this->helperImageFactory->create();
        return $this->assetRepos->getUrl($imagePlaceholder->getPlaceholder('small_image'));
    }
}
