<?php

namespace Forever\Blog\Controller\Adminhtml\Tag;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Framework\Controller\ResultFactory;
use Magento\Ui\Component\MassAction\Filter;
use Forever\Blog\Model\ResourceModel\Tag\CollectionFactory;

class MassDelete extends Action implements HttpPostActionInterface
{
    /**
     * @var CollectionFactory
     */
    protected $tagFactory;

    /**
     * @var Filter
     */
    protected $filter;

    /**
     * @param Context           $context
     * @param CollectionFactory $tagFactory
     * @param Filter            $filter
     */
    public function __construct(
        Context $context,
        CollectionFactory $tagFactory,
        Filter $filter
    ) {
        $this->tagFactory = $tagFactory;
        $this->filter = $filter;
        parent::__construct($context);
    }

    public function execute()
    {
        $collection = $this->filter->getCollection($this->tagFactory->create());
        $recordDeleted = 0;
        foreach ($collection->getItems() as $record) {
            $record->setId($record->getTagId());
            $record->delete();
            $recordDeleted++;
        }
        $this->messageManager->addSuccessMessage(__('A total of %1 record(s) have been deleted.', $recordDeleted));

        return $this->resultFactory->create(ResultFactory::TYPE_REDIRECT)->setPath('blog/tag/index');
    }

    /**
     * @return bool
     */
    protected function isAllowed()
    {
        return $this->_authorization->isAllowed('Forever_Blog::home');
    }
}
