<?php

namespace Forever\Blog\Block;

use Magento\Framework\View\Element\Template;
use Forever\Blog\Model\BlogFactory;
use Forever\Blog\Model\ResourceModel\Blog as BlogResource;
use Magento\Framework\View\Asset\Repository;
use Magento\Catalog\Helper\ImageFactory;

class View extends Template
{
    /**
     * @var BlogFactory
     */
    protected $blogFactory;

    /**
     * @var BlogResource
     */
    protected $blogResource;

    /**
     * @var Repository
     */
    protected $assetRepos;

    /**
     * @var ImageFactory
     */
    protected $helperImageFactory;

    /**
     * @param Template\Context $context
     * @param BlogFactory      $blogFactory
     * @param BlogResource     $blogResource
     * @param Repository       $assetRepos
     * @param ImageFactory     $helperImageFactory
     * @param array            $data
     */
    public function __construct(
        Template\Context $context,
        BlogFactory $blogFactory,
        BlogResource $blogResource,
        Repository $assetRepos,
        ImageFactory $helperImageFactory,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->blogFactory = $blogFactory;
        $this->blogResource = $blogResource;
        $this->assetRepos = $assetRepos;
        $this->helperImageFactory = $helperImageFactory;
    }

    /**
     * @param  string $urlKey
     * @return \Forever\Blog\Model\Blog
     */
    public function getPost($urlKey)
    {
        $model = $this->blogFactory->create();
        $this->blogResource->load($model, $urlKey, 'url_key');
        return $model;
    }

    /**
     * @return string
     */
    public function getPlaceHolderImage()
    {
        $imagePlaceholder = $this->helperImageFactory->create();
        return $this->assetRepos->getUrl($imagePlaceholder->getPlaceholder('small_image'));
    }
}
