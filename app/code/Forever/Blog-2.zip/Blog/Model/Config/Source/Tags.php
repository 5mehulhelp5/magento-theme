<?php

namespace Forever\Blog\Model\Config\Source;

use Magento\Framework\Data\OptionSourceInterface;

class Tags implements OptionSourceInterface
{
    /**
     * @var \Forever\Blog\Model\ResourceModel\Tag\CollectionFactory
     */
    protected $collectionFactory;

    /**
     * @param \Forever\Blog\Model\ResourceModel\Tag\CollectionFactory $collectionFactory
     */
    public function __construct(
        \Forever\Blog\Model\ResourceModel\Tag\CollectionFactory $collectionFactory
    ) {
        $this->collectionFactory = $collectionFactory;
    }

    /**
     * Return array of options as value-label pairs
     *
     * @return array
     */
    public function toOptionArray()
    {
        $tagCollection = $this->collectionFactory->create()->addFieldToFilter('status', ['eq' => '1']);
        $options = [];
        foreach ($tagCollection as $tag) {
            $options[] = [
                'label' => $tag->getTitle(),
                'value' => $tag->getId()
            ];
        }
        return $options;
    }
}
